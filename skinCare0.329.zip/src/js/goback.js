// (function goback(){
//     const _this=this;
//     // console.log("goback")
//     var url=window.location.href,
//         nogo=url.substring(url.lastIndexOf('/')-1,url.lastIndexOf('/'));
//         console.log(nogo)
//     console.log(window.location.href)
//     if(!localStorage.getItem("username")){
//         window.location.href="/"; //用户没登录跳转登录页面 
//     }
// })
